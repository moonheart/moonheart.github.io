MODID=fomey.smalipatcher

AUTOMOUNT=true

PROPFILE=false

POSTFSDATA=false

LATESTARTSERVICE=false

print_modname() {
  ui_print "******************************"
  ui_print "         替换services.jar         "
  ui_print "             moonheart          "
}

REPLACE="
/system/framework/services.jar
/system/framework/oat/arm/services.odex
/system/framework/oat/arm64/services.odex
/system/framework/arm/services.odex
/system/framework/arm64/services.odex
"

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}
